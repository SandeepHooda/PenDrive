export default class Asset {
  assetId: number;
  assetName: string;
  assetCategory: string;
  assetDescription: string;
  dateOfPurchase: string;
  assetCost: number;
}

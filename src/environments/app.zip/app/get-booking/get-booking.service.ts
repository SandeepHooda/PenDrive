import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { BuffetBooking } from '../buffet-booking/buffet-booking';
import { Observable, throwError } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class GetBookingService {

  constructor(private http: HttpClient) { }

  url = "http://localhost:3000/fetchBooking/";
  getBooking(id):Observable<BuffetBooking> {
    /*
    Consumes the web service exposed at the URI -> http://localhost:3000/fetchBooking/:id
    After sending the request, the response must be converted to an observable object of type BuffetBooking
    Return the response back to the Get booking Component
  */
    return this.http.get<BuffetBooking>(this.url + id);
    /*.pipe(
      catchError(this.handleError)
    );*/
  }

  private handleError(err: HttpErrorResponse) {
    let errMsg = '';
    if (err.error instanceof Error) {
      // A client-side or network error occurred. Handle it accordingly.
      console.log('An error occurred:', err.error.message);
      errMsg = err.error.message;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.log(`Backend returned code ${err.status}`);
      errMsg = err.error;
    }
    return throwError(errMsg);
  }
}


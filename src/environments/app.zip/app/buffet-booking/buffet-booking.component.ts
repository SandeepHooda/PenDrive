import { Component, OnInit } from '@angular/core';

import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {BuffetBookingService} from './buffet-booking.service';

@Component({
  selector: 'app-buffet-booking',
  templateUrl: './buffet-booking.component.html',
  styleUrls: ['./buffet-booking.component.css']
})
export class BuffetBookingComponent implements OnInit {

  errorMessage: string;
  successMessage: string;
  buffetBookingForm: FormGroup;

  constructor(private fb: FormBuilder,private bbservice:BuffetBookingService) { }


  ngOnInit() {
    //Add specified validators
    this.buffetBookingForm = this.fb.group({
      buffetName: ["",Validators.required],
      emailId: ["",[Validators.required,Validators.email]],
      plateCount: ["",[Validators.required,Validators.min(1)]],
      bookedOn: ["",Validators.required]
    })
  }


  bookBuffet() {
    /*
    It should invoke bookBuffet() of BuffetBookingService 
    by passing the value of buffetBookingForm object as a parameter, which in turn returns a observable
    The success callback should populate the successMessage with the message in response
    The error callback should populate the errorMessage with the message in response
  */
  this.bbservice.bookBuffet(this.buffetBookingForm.value).subscribe(success=>{
    this.successMessage=success.message;
    this.errorMessage=null;

  },
    error=>{
      this.errorMessage=error.error.message;
    this.successMessage=null;

    })
  }

}

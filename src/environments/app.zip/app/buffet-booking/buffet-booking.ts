//Model class to store data
export class BuffetBooking {
    bookingId: number;
    buffetName: string;
    emailId: string;
    plateCount: number;
    bookedOn: Date;
    message: string;
}
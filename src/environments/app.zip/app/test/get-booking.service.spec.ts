import { TestBed, inject } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';

import { GetBookingService } from '../get-booking/get-booking.service';
import { HttpClient } from '@angular/common/http';

///////////////////////Fetching valid data///////////////
fdescribe('Testing fetching data through GetBookingService', () => {

  let httpMock: HttpTestingController;
  let dataService: GetBookingService
  const mockResponse:any= '{"bookingId":1001,"buffetName":"SouthIndianSpcl","emailId":"absy@infy.com","plateCount":"4","bookedOn":"2018-08-12T18:30:00.000Z"}';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [GetBookingService]
    });

    dataService = TestBed.get(GetBookingService);
    httpMock = TestBed.get(HttpTestingController);
  });

  it('TS 1/2 - Get_Booking:Service should return observable', inject([GetBookingService, HttpTestingController], (service, httpMock) => {
    let data;
    service.getBooking(1001).subscribe((response) => {
      data = response;
    });
    const mockReq = httpMock.expectOne('http://localhost:3000/fetchBooking/1001');
    mockReq.flush(mockResponse); // Send response when URL is given
    httpMock.verify();
    expect(data).toBe('{"bookingId":1001,"buffetName":"SouthIndianSpcl","emailId":"absy@infy.com","plateCount":"4","bookedOn":"2018-08-12T18:30:00.000Z"}');
  }))

  it('TS 2/2 - Get_Booking:Service should be called using GET method', inject([HttpClient], (http: HttpClient) => {
    const spy = spyOn(http, "get")
    dataService.getBooking(1001);
    expect(spy).toHaveBeenCalled();
  }))
});
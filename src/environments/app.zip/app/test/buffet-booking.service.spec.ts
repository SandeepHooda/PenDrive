import { TestBed, inject, async } from '@angular/core/testing';
import { HttpTestingController, HttpClientTestingModule } from '@angular/common/http/testing';
import {BuffetBooking} from '../buffet-booking/buffet-booking';
import { BuffetBookingService } from '../buffet-booking/buffet-booking.service';
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';

///////////////////////Fetching valid data///////////////
fdescribe('Testing fetching data through BuffetBookingService', () => {

  let httpMock: HttpTestingController;
  let dataService: BuffetBookingService;
  const mockResponse:any = '{"buffetName":"ChineseSpcl","bookedOn":2018-6-14,"emailId":"luvina@infy.com","plateCount":4}';

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [BuffetBookingService]
    });
    httpMock = TestBed.get(HttpTestingController);
    dataService = TestBed.get(BuffetBookingService);
  });

  it('TS 1/3 - Buffet_Booking:Service should return observable', inject([HttpTestingController, BuffetBookingService], (httpMock, service) => {
    service.bookBuffet().subscribe((response) => {
      expect(response).toBe('{"buffetName":"ChineseSpcl","bookedOn":2018-6-14,"emailId":"luvina@infy.com","plateCount":4}')
    })
    const mockReq = httpMock.expectOne(dataService.url);
    mockReq.flush(mockResponse);
    httpMock.verify();
  }))

  it('TS 2/3 Service Should call appropriate URL', () => {
    expect(dataService.url).toBe('http://localhost:3000/bookBuffet');
  })

  it('TS 3/3 - Buffet_Booking:Service should be called using POST method', inject([HttpClient], (http: HttpClient) => {
    const spy = spyOn(http, "post").and.returnValue(of({ message: 'Success' }));
    dataService.bookBuffet(mockResponse);
    expect(spy).toHaveBeenCalled();
  }))
});



